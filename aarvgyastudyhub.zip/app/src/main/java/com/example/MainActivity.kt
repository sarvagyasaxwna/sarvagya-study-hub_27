package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.example.data.database.StudyDatabase
import com.example.data.repository.StudyRepository
import com.example.ui.StudyViewModel
import com.example.ui.screens.StudyHubMainScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize SQLite Local Room Persistence Engine
        val database = StudyDatabase.getDatabase(applicationContext)
        val dao = database.studyDao()
        val repository = StudyRepository(dao)

        // Initialize Android Architecture ViewModel with Simple Constructor injection factory
        val viewModel = ViewModelProvider(
            this,
            StudyViewModel.Factory(application, repository)
        )[StudyViewModel::class.java]

        setContent {
            MyApplicationTheme {
                StudyHubMainScreen(viewModel = viewModel)
            }
        }
    }
}
