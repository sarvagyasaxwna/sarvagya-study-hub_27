package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_quizzes")
data class SavedQuiz(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val quizJson: String,
    val score: Int = 0,
    val totalQuestions: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)
