package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyDao {
    // Tasks
    @Query("SELECT * FROM study_tasks ORDER BY timestamp DESC")
    fun getAllTasksFlow(): Flow<List<StudyTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: StudyTask)

    @Update
    suspend fun updateTask(task: StudyTask)

    @Query("DELETE FROM study_tasks WHERE id = :id")
    suspend fun deleteTaskById(id: Int)

    @Query("DELETE FROM study_tasks")
    suspend fun clearAllTasks()

    // Sessions
    @Query("SELECT * FROM study_sessions ORDER BY timestamp DESC")
    fun getAllSessionsFlow(): Flow<List<StudySession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: StudySession)

    @Query("DELETE FROM study_sessions")
    suspend fun clearAllSessions()

    // Quizzes
    @Query("SELECT * FROM saved_quizzes ORDER BY timestamp DESC")
    fun getAllQuizzesFlow(): Flow<List<SavedQuiz>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuiz(quiz: SavedQuiz)

    @Query("DELETE FROM saved_quizzes WHERE id = :id")
    suspend fun deleteQuizById(id: Int)

    @Query("DELETE FROM saved_quizzes")
    suspend fun clearAllQuizzes()
}
