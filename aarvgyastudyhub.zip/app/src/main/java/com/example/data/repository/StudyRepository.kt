package com.example.data.repository

import android.util.Log
import com.example.BuildConfig
import com.example.data.api.Content
import com.example.data.api.GeminiApiService
import com.example.data.api.GeminiRetrofitClient
import com.example.data.api.GenerateContentRequest
import com.example.data.api.GenerationConfig
import com.example.data.api.Part
import com.example.data.api.QuizData
import com.example.data.database.SavedQuiz
import com.example.data.database.StudyDao
import com.example.data.database.StudySession
import com.example.data.database.StudyTask
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class StudyRepository(
    private val studyDao: StudyDao,
    private val apiService: GeminiApiService = GeminiRetrofitClient.service
) {
    // Flows
    val allTasks: Flow<List<StudyTask>> = studyDao.getAllTasksFlow()
    val allSessions: Flow<List<StudySession>> = studyDao.getAllSessionsFlow()
    val allQuizzes: Flow<List<SavedQuiz>> = studyDao.getAllQuizzesFlow()

    // Task CRUD
    suspend fun insertTask(task: StudyTask) = withContext(Dispatchers.IO) {
        studyDao.insertTask(task)
    }

    suspend fun updateTask(task: StudyTask) = withContext(Dispatchers.IO) {
        studyDao.updateTask(task)
    }

    suspend fun deleteTaskById(id: Int) = withContext(Dispatchers.IO) {
        studyDao.deleteTaskById(id)
    }

    suspend fun clearAllTasks() = withContext(Dispatchers.IO) {
        studyDao.clearAllTasks()
    }

    // Session Operations
    suspend fun insertSession(session: StudySession) = withContext(Dispatchers.IO) {
        studyDao.insertSession(session)
    }

    suspend fun clearAllSessions() = withContext(Dispatchers.IO) {
        studyDao.clearAllSessions()
    }

    // Quiz Operations
    suspend fun insertQuiz(quiz: SavedQuiz) = withContext(Dispatchers.IO) {
        studyDao.insertQuiz(quiz)
    }

    suspend fun deleteQuizById(id: Int) = withContext(Dispatchers.IO) {
        studyDao.deleteQuizById(id)
    }

    suspend fun clearAllQuizzes() = withContext(Dispatchers.IO) {
        studyDao.clearAllQuizzes()
    }

    // Gemini API Call
    suspend fun generateQuiz(extractedText: String, targetFormat: String): QuizData = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            throw IllegalStateException("Gemini API Key is not configured. Please add your key to the Secrets panel.")
        }

        val prompt = """
            You are an expert educational AI integrated into Sarvagya Study Hub.
            Analyze the following study material text and output a highly comprehensive quiz containing 4 to 8 questions.
            Target format constraint: $targetFormat.
            
            You must strictly output raw JSON matching this structure exactly:
            {
              "quizTitle": "string",
              "questions": [
                {
                  "id": 1,
                  "type": "MCQ" | "TrueFalse" | "FillBlank",
                  "questionText": "string",
                  "options": ["string"] (provide exactly 4 options for MCQ, exactly 2 options for TrueFalse (e.g. ["True", "False"]), null or empty for FillBlank),
                  "correctAnswer": "string",
                  "explanation": "string"
                }
              ]
            }
            
            Do NOT include markdown blocks, wrapper text, or code formatting like ```json. Start your response directly with { and end with }.
            
            Source Text Material:
            $extractedText
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(
                Content(
                    parts = listOf(
                        Part(text = prompt)
                    )
                )
            ),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                temperature = 0.2f
            )
        )

        try {
            // Using basic text model gemini-3.5-flash as mandated by gemini-api skill
            val response = apiService.generateContent(
                model = "gemini-3.5-flash",
                apiKey = apiKey,
                request = request
            )

            val textResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: throw IllegalStateException("Empty response from Gemini AI pipeline.")

            Log.d("StudyRepository", "Raw Gemini Response: $textResponse")

            // Clean up backticks or header wrappers in case the model ignored system instructions
            var cleanedText = textResponse.trim()
            if (cleanedText.startsWith("```json")) {
                cleanedText = cleanedText.substring(7)
            } else if (cleanedText.startsWith("```")) {
                cleanedText = cleanedText.substring(3)
            }
            if (cleanedText.endsWith("```")) {
                cleanedText = cleanedText.substring(0, cleanedText.length - 3)
            }
            cleanedText = cleanedText.trim()

            val adapter = GeminiRetrofitClient.getMoshi().adapter(QuizData::class.java)
            val quizData = adapter.fromJson(cleanedText)
                ?: throw IllegalStateException("Failed to parse the quiz JSON structure.")

            quizData
        } catch (e: Exception) {
            Log.e("StudyRepository", "Gemini pipeline generation failure", e)
            throw e
        }
    }
}
