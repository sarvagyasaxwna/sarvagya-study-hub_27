package com.example.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.api.QuizData
import com.example.data.api.GeminiRetrofitClient
import com.example.data.database.SavedQuiz
import com.example.data.database.StudyDatabase
import com.example.data.database.StudySession
import com.example.data.database.StudyTask
import com.example.data.repository.StudyRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class StudyViewModel(
    application: Application,
    private val repository: StudyRepository
) : AndroidViewModel(application) {

    // Database flows
    val tasks: StateFlow<List<StudyTask>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sessions: StateFlow<List<StudySession>> = repository.allSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedQuizzes: StateFlow<List<SavedQuiz>> = repository.allQuizzes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Active Timer State ---
    var activeSubject by mutableStateOf("Applied Physics")
    var timerDurationSeconds by mutableStateOf(1500L) // 25:00 default
    var initialDurationSeconds by mutableStateOf(1500L)
    var isTimerRunning by mutableStateOf(false)
    var timerCompletedEvent by mutableStateOf(false)
    private var timerJob: Job? = null

    // --- Quiz Generation State ---
    var studyTextSource by mutableStateOf("")
    var selectedFormat by mutableStateOf("MCQ") // MCQ, TrueFalse, FillBlank
    var isQuizGenerating by mutableStateOf(false)
    var quizGenerationError by mutableStateOf<String?>(null)
    var activeQuiz by mutableStateOf<QuizData?>(null)

    // Current quiz play state
    var currentQuestionIndex by mutableStateOf(0)
    var selectedAnswer by mutableStateOf<String?>(null)
    var isAnswerSubmitted by mutableStateOf(false)
    var correctAnswersCount by mutableStateOf(0)
    var quizCompleted by mutableStateOf(false)

    // Selected Saved Quiz to display or retake
    var viewHistoryQuiz by mutableStateOf<SavedQuiz?>(null)

    init {
        // Pre-populate some baseline data if database is empty, so it's ready-to-test
        viewModelScope.launch {
            repository.allTasks.collect { list ->
                if (list.isEmpty()) {
                    injectSampleData()
                }
            }
        }
    }

    // Timer control functions
    fun startTimer() {
        if (isTimerRunning) return
        isTimerRunning = true
        timerJob = viewModelScope.launch {
            while (timerDurationSeconds > 0) {
                delay(1000L)
                timerDurationSeconds--
            }
            onTimerFinished()
        }
    }

    fun pauseTimer() {
        isTimerRunning = false
        timerJob?.cancel()
    }

    fun resetTimer() {
        pauseTimer()
        timerDurationSeconds = initialDurationSeconds
    }

    fun changeTimerInitialDuration(minutes: Int) {
        pauseTimer()
        initialDurationSeconds = minutes * 60L
        timerDurationSeconds = initialDurationSeconds
    }

    private fun onTimerFinished() {
        isTimerRunning = false
        timerCompletedEvent = true
        // Save study session to database
        viewModelScope.launch {
            repository.insertSession(
                StudySession(
                    subject = activeSubject,
                    durationSeconds = initialDurationSeconds
                )
            )
        }
        resetTimer()
    }

    // Task CRUD operations
    fun addTask(title: String, subject: String) {
        viewModelScope.launch {
            repository.insertTask(
                StudyTask(title = title, subject = subject, isCompleted = false)
            )
        }
    }

    fun toggleTaskCompletion(task: StudyTask) {
        viewModelScope.launch {
            repository.updateTask(task.copy(isCompleted = !task.isCompleted))
        }
    }

    fun deleteTask(id: Int) {
        viewModelScope.launch {
            repository.deleteTaskById(id)
        }
    }

    // Quiz Actions
    fun generateQuizFromInput() {
        val text = studyTextSource.trim()
        if (text.isEmpty()) {
            quizGenerationError = "Please enter reference study text or notes."
            return
        }

        isQuizGenerating = true
        quizGenerationError = null
        activeQuiz = null

        viewModelScope.launch {
            try {
                val formatText = when (selectedFormat) {
                    "MCQ" -> "Multiple Choice Questions only (each question must have options array with exactly 4 options)"
                    "TrueFalse" -> "True/False questions only (each question must have options array with exactly ['True', 'False'])"
                    else -> "Fill in the blank style questions"
                }

                val quizData = repository.generateQuiz(text, formatText)
                activeQuiz = quizData
                resetQuizPlayState()
            } catch (e: Exception) {
                quizGenerationError = e.message ?: "Pipeline failure processing materials."
            } finally {
                isQuizGenerating = false
            }
        }
    }

    fun resetQuizPlayState() {
        currentQuestionIndex = 0
        selectedAnswer = null
        isAnswerSubmitted = false
        correctAnswersCount = 0
        quizCompleted = false
    }

    fun submitAnswer() {
        if (isAnswerSubmitted) return
        val currentQuiz = activeQuiz ?: return
        val question = currentQuiz.questions.getOrNull(currentQuestionIndex) ?: return

        isAnswerSubmitted = true
        if (selectedAnswer == question.correctAnswer) {
            correctAnswersCount++
        }
    }

    fun nextQuestion() {
        val currentQuiz = activeQuiz ?: return
        if (currentQuestionIndex + 1 < currentQuiz.questions.size) {
            currentQuestionIndex++
            selectedAnswer = null
            isAnswerSubmitted = false
        } else {
            quizCompleted = true
            // Save quiz history
            viewModelScope.launch {
                val moshi = GeminiRetrofitClient.getMoshi()
                val jsonAdapter = moshi.adapter(QuizData::class.java)
                val quizJson = jsonAdapter.toJson(currentQuiz)

                repository.insertQuiz(
                    SavedQuiz(
                        title = currentQuiz.quizTitle,
                        quizJson = quizJson,
                        score = correctAnswersCount,
                        totalQuestions = currentQuiz.questions.size
                    )
                )
            }
        }
    }

    fun deleteSavedQuiz(quizId: Int) {
        viewModelScope.launch {
            repository.deleteQuizById(quizId)
        }
    }

    fun retakeSavedQuiz(savedQuiz: SavedQuiz) {
        viewModelScope.launch {
            try {
                val moshi = GeminiRetrofitClient.getMoshi()
                val jsonAdapter = moshi.adapter(QuizData::class.java)
                val quizData = jsonAdapter.fromJson(savedQuiz.quizJson)
                if (quizData != null) {
                    activeQuiz = quizData
                    resetQuizPlayState()
                }
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    // Mock data population
    fun injectSampleData() {
        viewModelScope.launch {
            repository.clearAllTasks()
            repository.clearAllSessions()

            // Pre-populate 5 diverse completed and non-completed tasks
            val sampleTasks = listOf(
                StudyTask(title = "Revise Applied Physics Lecture Notes", subject = "Applied Physics", isCompleted = true),
                StudyTask(title = "Solve Thermodynamics Exercise Q1-Q10", subject = "Applied Physics", isCompleted = false),
                StudyTask(title = "Read Organic Chemistry Chapter 4", subject = "Organic Chemistry", isCompleted = true),
                StudyTask(title = "Complete Calculus Homework sheet", subject = "Mathematics", isCompleted = false),
                StudyTask(title = "Review Machine Learning Cost Functions", subject = "Computer Science", isCompleted = true),
                StudyTask(title = "Practice Chemistry Nomenclature MCQs", subject = "Organic Chemistry", isCompleted = false)
            )
            sampleTasks.forEach { repository.insertTask(it) }

            // Pre-populate study sessions (Total study hours: 42.5h is around 153000 seconds)
            // We'll insert a few sessions representing solid progress
            val sampleSessions = listOf(
                StudySession(subject = "Applied Physics", durationSeconds = 5400L), // 1.5h
                StudySession(subject = "Organic Chemistry", durationSeconds = 7200L), // 2.0h
                StudySession(subject = "Mathematics", durationSeconds = 10800L), // 3.0h
                StudySession(subject = "Computer Science", durationSeconds = 9000L), // 2.5h
                StudySession(subject = "Applied Physics", durationSeconds = 3600L) // 1.0h
            )
            sampleSessions.forEach { repository.insertSession(it) }
        }
    }

    fun resetAllData() {
        viewModelScope.launch {
            repository.clearAllTasks()
            repository.clearAllSessions()
            repository.clearAllQuizzes()
        }
    }

    class Factory(
        private val application: Application,
        private val repository: StudyRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(StudyViewModel::class.java)) {
                return StudyViewModel(application, repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
