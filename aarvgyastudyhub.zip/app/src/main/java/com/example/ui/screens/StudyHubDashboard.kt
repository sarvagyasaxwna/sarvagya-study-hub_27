package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.api.QuizData
import com.example.data.api.QuizQuestion
import com.example.data.database.SavedQuiz
import com.example.data.database.StudySession
import com.example.data.database.StudyTask
import com.example.ui.StudyViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.delay

enum class ActiveTab {
    HOME, LIBRARY, QUIZ, SETTINGS
}

@Composable
fun StudyHubMainScreen(viewModel: StudyViewModel) {
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf(ActiveTab.HOME) }

    // Display a toast when the timer finishes
    LaunchedEffect(viewModel.timerCompletedEvent) {
        if (viewModel.timerCompletedEvent) {
            Toast.makeText(
                context,
                "🎉 Excellent focus session on ${viewModel.activeSubject} completed! Recorded in hub telemetry.",
                Toast.LENGTH_LONG
            ).show()
            viewModel.timerCompletedEvent = false
        }
    }

    Scaffold(
        bottomBar = {
            GlassBottomNavigation(
                activeTab = activeTab,
                onTabSelected = { activeTab = it }
            )
        },
        containerColor = DarkBackground,
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Elegant background ambient glows
            AmbientBackgroundGlows()

            // Main content based on active tab
            when (activeTab) {
                ActiveTab.HOME -> DashboardTab(
                    viewModel = viewModel,
                    onNavigateToQuiz = { activeTab = ActiveTab.QUIZ }
                )
                ActiveTab.LIBRARY -> LibraryTab(viewModel = viewModel)
                ActiveTab.QUIZ -> QuizTab(viewModel = viewModel)
                ActiveTab.SETTINGS -> SettingsTab(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun AmbientBackgroundGlows() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        // Top-left purple glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x267F00FF), Color.Transparent),
                center = Offset(0f, 0f),
                radius = size.width * 0.8f
            ),
            radius = size.width * 0.8f,
            center = Offset(0f, 0f)
        )
        // Bottom-right cyan glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x1A00F2FE), Color.Transparent),
                center = Offset(size.width, size.height),
                radius = size.width * 0.8f
            ),
            radius = size.width * 0.8f,
            center = Offset(size.width, size.height)
        )
    }
}

// --- TAB 1: DASHBOARD ---
@Composable
fun DashboardTab(
    viewModel: StudyViewModel,
    onNavigateToQuiz: () -> Unit
) {
    val tasks by viewModel.tasks.collectAsStateWithLifecycle()
    val sessions by viewModel.sessions.collectAsStateWithLifecycle()

    // Calculate aggregated stats
    val totalStudySeconds = sessions.sumOf { it.durationSeconds }
    val totalStudyHours = totalStudySeconds / 3600f
    // Base pre-populated value to give high-fidelity initial dashboard mapping
    val displayHours = 42.5f + totalStudyHours

    val totalTasks = tasks.size
    val completedTasks = tasks.count { it.isCompleted }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // --- Header Section ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SARVAGYA HUB",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = BrightBlue,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                )
                Text(
                    text = "Dashboard",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = TextWhite,
                        fontWeight = FontWeight.Black,
                        letterSpacing = (-0.5).sp
                    )
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Animated Streak Fire Badge
                val infiniteTransition = rememberInfiniteTransition(label = "streak")
                val streakScale by infiniteTransition.animateFloat(
                    initialValue = 1f,
                    targetValue = 1.1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1200, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "streak_scale"
                )

                Row(
                    modifier = Modifier
                        .background(Color(0x1AFFFFFF), RoundedCornerShape(100.dp))
                        .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(100.dp))
                        .padding(horizontal = 12.dp, java.lang.Float.valueOf(6f).toInt().dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "🔥",
                        fontSize = 16.sp,
                        modifier = Modifier.drawBehind {
                            // Subtle backing glow
                        }
                    )
                    Text(
                        text = "12",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                // Profile circular avatar
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(BrightBlue, VividPurple)
                            )
                        )
                        .border(1.5.dp, Color(0x33FFFFFF), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "S",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }

        // --- Gemini AI Insights Card ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0x1A00F2FE),
                            Color(0x0F7F00FF),
                            Color.Transparent
                        )
                    )
                )
                .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(24.dp))
                .padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(Color(0x1A00F2FE), RoundedCornerShape(8.dp))
                            .padding(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "AI",
                            tint = ElectricCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = "GEMINI AI INSIGHTS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = BrightBlue,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                }

                Text(
                    text = "You're 24% more efficient in Applied Physics this week.",
                    color = TextWhite,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    lineHeight = 22.sp
                )

                Text(
                    text = "Your focus peaks between 08:00 and 10:30 AM. Ready for an AI-generated retention quiz to boost retention?",
                    color = TextGray,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Button(
                    onClick = onNavigateToQuiz,
                    colors = ButtonDefaults.buttonColors(containerColor = VividPurple),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .testTag("dashboard_quiz_shortcut"),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    Text(
                        text = "Generate AI Quiz",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // --- Progress Grid (Study Hours & Tasks Completed) ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Card 1: Study Hours
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(115.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0x0DFFFFFF))
                    .border(1.dp, Color(0x13FFFFFF), RoundedCornerShape(24.dp))
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "STUDY HOURS",
                        color = TextGray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )

                    Column {
                        Text(
                            text = String.format("%.1fh", displayHours),
                            color = TextWhite,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "+12% vs last week",
                            color = Color(0xFF4ADE80),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Card 2: Tasks Completed
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(115.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0x0DFFFFFF))
                    .border(1.dp, Color(0x13FFFFFF), RoundedCornerShape(24.dp))
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "TASKS MET",
                        color = TextGray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )

                    Column {
                        val taskRatioText = if (totalTasks > 0) "$completedTasks/$totalTasks" else "18/24"
                        Text(
                            text = taskRatioText,
                            color = TextWhite,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )

                        // Visual progress bar
                        Spacer(modifier = Modifier.height(8.dp))
                        val progressFraction = if (totalTasks > 0) completedTasks.toFloat() / totalTasks else 0.75f
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(CircleShape)
                                .background(Color(0x1AFFFFFF))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(progressFraction)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(ElectricCyan, BrightBlue)
                                        )
                                    )
                            )
                        }
                    }
                }
            }
        }

        // --- Active Session / Timer Section ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(28.dp))
                .background(Color(0x0DFFFFFF))
                .border(1.dp, Color(0x13FFFFFF), RoundedCornerShape(28.dp))
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header of Timer
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column {
                        Text(
                            text = "ACTIVE FOCUS",
                            color = TextGray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = viewModel.activeSubject,
                            color = TextWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(Color(0x1A4FACFE), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "POMODORO",
                            color = BrightBlue,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Radial timer background visual representation
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Draw clean minimalist progress circle
                    val sweepProgress = viewModel.timerDurationSeconds.toFloat() / viewModel.initialDurationSeconds.toFloat()
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        // Background circle
                        drawCircle(
                            color = Color(0x0DFFFFFF),
                            style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                        )
                        // Foreground glowing arc
                        drawArc(
                            brush = Brush.sweepGradient(
                                colors = listOf(VividPurple, ElectricCyan, VividPurple)
                            ),
                            startAngle = -90f,
                            sweepAngle = 360f * sweepProgress,
                            useCenter = false,
                            style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }

                    // Raw countdown label
                    val minutes = viewModel.timerDurationSeconds / 60
                    val seconds = viewModel.timerDurationSeconds % 60
                    val timeFormatted = String.format("%02d:%02d", minutes, seconds)

                    Text(
                        text = timeFormatted,
                        color = Color.White,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = (-1).sp
                    )
                }

                // Interactive subject selections and action control buttons
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Subjects chips scroll group to configure timer focus target
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val subjectsList = listOf("Applied Physics", "Organic Chemistry", "Mathematics", "Computer Science")
                        subjectsList.forEach { subj ->
                            val isSelected = viewModel.activeSubject == subj
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 4.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) Color(0x2600F2FE) else Color.Transparent)
                                    .border(
                                        1.dp,
                                        if (isSelected) ElectricCyan else Color(0x13FFFFFF),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        viewModel.activeSubject = subj
                                    }
                                    .padding(horizontal = 8.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text = if (subj == "Applied Physics") "Physics" else if (subj == "Organic Chemistry") "Chemistry" else subj,
                                    color = if (isSelected) ElectricCyan else TextGray,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Control Buttons
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Reset timer
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color(0x12FFFFFF))
                                .clickable { viewModel.resetTimer() }
                                .testTag("reset_timer_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Reset Timer",
                                tint = TextWhite,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Play / Pause toggle
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(if (viewModel.isTimerRunning) Color(0x267F00FF) else Color.White)
                                .clickable {
                                    if (viewModel.isTimerRunning) {
                                        viewModel.pauseTimer()
                                    } else {
                                        viewModel.startTimer()
                                    }
                                }
                                .testTag("start_timer_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (viewModel.isTimerRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play Pause Timer",
                                tint = if (viewModel.isTimerRunning) VividPurple else Color.Black,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        // Short-cuts config (Pomodoro duration setter)
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color(0x12FFFFFF))
                                .clickable {
                                    val currentInitialMin = viewModel.initialDurationSeconds / 60
                                    val nextMin = when (currentInitialMin) {
                                        25L -> 5
                                        5L -> 15
                                        15L -> 45
                                        else -> 25
                                    }
                                    viewModel.changeTimerInitialDuration(nextMin)
                                }
                                .testTag("set_timer_duration_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = "Set duration",
                                tint = TextWhite,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- TAB 2: LIBRARY / TASK CRUD WORKSPACE ---
@Composable
fun LibraryTab(viewModel: StudyViewModel) {
    val tasks by viewModel.tasks.collectAsStateWithLifecycle()

    var taskTitleInput by remember { mutableStateOf("") }
    var taskSubjectSelection by remember { mutableStateOf("Applied Physics") }

    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Tab header
        Column {
            Text(
                text = "STUDY WORKSPACE",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = BrightBlue,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            )
            Text(
                text = "Library & Tasks",
                style = MaterialTheme.typography.headlineMedium.copy(
                    color = TextWhite,
                    fontWeight = FontWeight.Black,
                    letterSpacing = (-0.5).sp
                )
            )
        }

        // Add task input panel
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0x0DFFFFFF))
                .border(1.dp, Color(0x13FFFFFF), RoundedCornerShape(24.dp))
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Add Study Goal",
                    color = TextWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = taskTitleInput,
                    onValueChange = { taskTitleInput = it },
                    placeholder = { Text("What study goal are you targeting today?", color = TextMuted, fontSize = 13.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedContainerColor = Color(0x0AFFFFFF),
                        unfocusedContainerColor = Color(0x0AFFFFFF),
                        focusedBorderColor = VividPurple,
                        unfocusedBorderColor = Color(0x1FFFFFFF)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("task_title_input"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { keyboardController?.hide() })
                )

                // Horizontal subject chip group to categorize the task
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val subjects = listOf("Applied Physics", "Organic Chemistry", "Mathematics", "Computer Science")
                    subjects.forEach { subj ->
                        val isSelected = taskSubjectSelection == subj
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) VividPurple else Color(0x0DFFFFFF))
                                .clickable { taskSubjectSelection = subj }
                                .padding(horizontal = 10.dp, vertical = java.lang.Float.valueOf(6f).toInt().dp)
                        ) {
                            Text(
                                text = if (subj == "Applied Physics") "Physics" else if (subj == "Organic Chemistry") "Chemistry" else subj,
                                color = if (isSelected) Color.White else TextGray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Button(
                    onClick = {
                        if (taskTitleInput.trim().isNotEmpty()) {
                            viewModel.addTask(taskTitleInput.trim(), taskSubjectSelection)
                            taskTitleInput = ""
                            keyboardController?.hide()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_task_button")
                ) {
                    Text("Add Daily Goal", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 13.sp)
                }
            }
        }

        // Active Goals title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ACTIVE GOALS (${tasks.size})",
                color = TextGray,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            if (tasks.isNotEmpty()) {
                Text(
                    text = "Clear All",
                    color = Color(0xFFEF4444),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { viewModel.resetAllData() }
                )
            }
        }

        // Lazy lists of study tasks
        if (tasks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AssignmentLate,
                        contentDescription = "Empty",
                        tint = TextMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = "No study goals defined yet.",
                        color = TextGray,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Use the panel above to add structured study sessions goals.",
                        color = TextMuted,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 32.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(tasks) { task ->
                    StudyTaskItemRow(
                        task = task,
                        onCheckedChange = { viewModel.toggleTaskCompletion(task) },
                        onDeleteClick = { viewModel.deleteTask(task.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun StudyTaskItemRow(
    task: StudyTask,
    onCheckedChange: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x06FFFFFF))
            .border(1.dp, Color(0x0FFFFFFF), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Checkbox
                Checkbox(
                    checked = task.isCompleted,
                    onCheckedChange = { onCheckedChange() },
                    colors = CheckboxDefaults.colors(
                        checkedColor = ElectricCyan,
                        uncheckedColor = Color(0x33FFFFFF),
                        checkmarkColor = Color.Black
                    ),
                    modifier = Modifier.testTag("task_item_checkbox")
                )

                Column {
                    Text(
                        text = task.title,
                        color = if (task.isCompleted) TextMuted else TextWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        style = if (task.isCompleted) LocalTextStyle.current.copy(
                            textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough
                        ) else LocalTextStyle.current,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Category tag pill
                    Box(
                        modifier = Modifier
                            .background(
                                when (task.subject) {
                                    "Applied Physics" -> Color(0x1A7F00FF)
                                    "Organic Chemistry" -> Color(0x1AFB923C)
                                    "Mathematics" -> Color(0x1A4FACFE)
                                    else -> Color(0x1A00F2FE)
                                },
                                RoundedCornerShape(6.dp)
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (task.subject == "Applied Physics") "Physics" else if (task.subject == "Organic Chemistry") "Chemistry" else task.subject,
                            color = when (task.subject) {
                                "Applied Physics" -> VividPurple
                                "Organic Chemistry" -> SoftOrange
                                "Mathematics" -> BrightBlue
                                else -> ElectricCyan
                            },
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            IconButton(
                onClick = onDeleteClick,
                modifier = Modifier.testTag("delete_task_button")
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Delete Task",
                    tint = Color(0xFFEF4444),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

// --- TAB 3: QUIZ / AI GENERATOR ENGINE ---
@Composable
fun QuizTab(viewModel: StudyViewModel) {
    val savedQuizzes by viewModel.savedQuizzes.collectAsStateWithLifecycle()

    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Tab Header
        Column {
            Text(
                text = "EDUCATIONAL COGNITIVE SERVICE",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = BrightBlue,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            )
            Text(
                text = "Gemini AI Quiz Engine",
                style = MaterialTheme.typography.headlineMedium.copy(
                    color = TextWhite,
                    fontWeight = FontWeight.Black,
                    letterSpacing = (-0.5).sp
                )
            )
        }

        if (viewModel.isQuizGenerating) {
            // Elegant Cosmic AI Generating State
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    CircularProgressIndicator(
                        color = ElectricCyan,
                        strokeWidth = 4.dp,
                        modifier = Modifier.size(54.dp)
                    )
                    Text(
                        text = "Gemini API parsing study materials...",
                        color = ElectricCyan,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Structuring customized educational schemas, generating optimal distractors, and drafting smart explanations.",
                        color = TextGray,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 40.dp)
                    )
                }
            }
        } else if (viewModel.activeQuiz != null) {
            // Active quiz game play board
            QuizPlayBoard(viewModel = viewModel)
        } else {
            // Setup quiz & history dashboard
            QuizGenerationSetup(
                viewModel = viewModel,
                savedQuizzes = savedQuizzes,
                keyboardController = keyboardController
            )
        }
    }
}

@Composable
fun ColumnScope.QuizGenerationSetup(
    viewModel: StudyViewModel,
    savedQuizzes: List<SavedQuiz>,
    keyboardController: androidx.compose.ui.platform.SoftwareKeyboardController?
) {
    var isHistorySelected by remember { mutableStateOf(false) }

    // Toggle menu
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0x0DFFFFFF))
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(if (!isHistorySelected) VividPurple else Color.Transparent)
                .clickable { isHistorySelected = false }
                .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("AI Generator", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Box(
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(if (isHistorySelected) VividPurple else Color.Transparent)
                .clickable { isHistorySelected = true }
                .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Past Quizzes", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }

    if (!isHistorySelected) {
        // AI generator configuration
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0x0DFFFFFF))
                .border(1.dp, Color(0x13FFFFFF), RoundedCornerShape(24.dp))
                .padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    text = "Configure Study Reference material",
                    color = TextWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                // Big reference text field
                OutlinedTextField(
                    value = viewModel.studyTextSource,
                    onValueChange = { viewModel.studyTextSource = it },
                    placeholder = {
                        Text(
                            "Type your notes here, paste reference chapters, or choose a predefined preset below to test...",
                            color = TextMuted,
                            fontSize = 13.sp
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedContainerColor = Color(0x0AFFFFFF),
                        unfocusedContainerColor = Color(0x0AFFFFFF),
                        focusedBorderColor = ElectricCyan,
                        unfocusedBorderColor = Color(0x1FFFFFFF)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .testTag("study_notes_input_area"),
                    maxLines = 6
                )

                // Quick educational presets tags to test instantly
                Text(
                    text = "QUICK STUDY THEME PRESETS",
                    color = TextGray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val presets = listOf(
                        "Quantum Physics" to "Quantum electrodynamics study. Schrodinger's equation outlines wavefunctions, wave-particle duality, Copenhagen quantum mechanics postulates.",
                        "Organic Chemistry" to "Nomenclature of functional organic molecules. Alkanes, Alkenes, Alkynes structure. Esterification reactions and carbonyl condensation mechanism."
                    )
                    presets.forEach { (label, content) ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0x0DFFFFFF))
                                .border(1.dp, Color(0x0FFFFFFF), RoundedCornerShape(10.dp))
                                .clickable {
                                    viewModel.studyTextSource = content
                                }
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(label, color = ElectricCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "Tap to inject",
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }

                // Format selection
                Text(
                    text = "TARGET FORMAT",
                    color = TextGray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val formats = listOf("MCQ", "TrueFalse", "FillBlank")
                    formats.forEach { fmt ->
                        val isSel = viewModel.selectedFormat == fmt
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) Color(0x1A00F2FE) else Color.Transparent)
                                .border(1.dp, if (isSel) ElectricCyan else Color(0x13FFFFFF), RoundedCornerShape(8.dp))
                                .clickable { viewModel.selectedFormat = fmt }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (fmt == "TrueFalse") "True / False" else if (fmt == "FillBlank") "Fill Blank" else "MCQ Options",
                                color = if (isSel) ElectricCyan else TextGray,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                if (viewModel.quizGenerationError != null) {
                    Text(
                        text = viewModel.quizGenerationError!!,
                        color = Color(0xFFEF4444),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = {
                        keyboardController?.hide()
                        viewModel.generateQuizFromInput()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VividPurple),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_quiz_button"),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Text("Draft Custom AI Quiz", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
    } else {
        // Quiz histories listing
        if (savedQuizzes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.HistoryEdu,
                        contentDescription = "Empty History",
                        tint = TextMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = "No saved quizzes found.",
                        color = TextGray,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Once you generate and answer an AI quiz, history tracks your study performance here.",
                        color = TextMuted,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 32.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(savedQuizzes) { item ->
                    SavedQuizHistoryItem(
                        savedQuiz = item,
                        onRetake = { viewModel.retakeSavedQuiz(item) },
                        onDelete = { viewModel.deleteSavedQuiz(item.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun SavedQuizHistoryItem(
    savedQuiz: SavedQuiz,
    onRetake: () -> Unit,
    onDelete: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x0DFFFFFF))
            .border(1.dp, Color(0x13FFFFFF), RoundedCornerShape(16.dp))
            .clickable { onRetake() }
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = savedQuiz.title,
                    color = TextWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Score: ${savedQuiz.score} / ${savedQuiz.totalQuestions}",
                        color = ElectricCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Box(
                        modifier = Modifier
                            .background(Color(0x12FFFFFF), RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        val scorePct = if (savedQuiz.totalQuestions > 0) {
                            (savedQuiz.score * 100) / savedQuiz.totalQuestions
                        } else 0
                        Text(
                            text = "$scorePct% mastery",
                            color = TextGray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.testTag("delete_saved_quiz")
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Delete Saved Quiz",
                    tint = Color(0xFFEF4444),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun QuizPlayBoard(viewModel: StudyViewModel) {
    val quiz = viewModel.activeQuiz ?: return
    val totalQ = quiz.questions.size

    if (viewModel.quizCompleted) {
        // Quiz Complete Results Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0x0DFFFFFF))
                .border(1.dp, Color(0x13FFFFFF), RoundedCornerShape(24.dp))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(Color(0x1A00F2FE)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Complete",
                        tint = ElectricCyan,
                        modifier = Modifier.size(44.dp)
                    )
                }

                Text(
                    text = "Quiz Complete!",
                    color = TextWhite,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )

                Text(
                    text = "You scored ${viewModel.correctAnswersCount} out of $totalQ correct answers.",
                    color = TextGray,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )

                val pct = if (totalQ > 0) (viewModel.correctAnswersCount * 100) / totalQ else 0
                Box(
                    modifier = Modifier
                        .background(Color(0x1A7F00FF), RoundedCornerShape(12.dp))
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "Score percentage: $pct% Mastery",
                        color = BrightBlue,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                }

                Button(
                    onClick = { viewModel.activeQuiz = null },
                    colors = ButtonDefaults.buttonColors(containerColor = VividPurple),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("restart_quiz_setup")
                ) {
                    Text("Return to Hub Setup", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    } else {
        // Standard interactive play question sheet
        val question = quiz.questions.getOrNull(viewModel.currentQuestionIndex) ?: return

        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Title & progress header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = quiz.quizTitle.uppercase(),
                        color = BrightBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth(0.7f)
                    )
                    Text(
                        text = "Question ${viewModel.currentQuestionIndex + 1} of $totalQ",
                        color = TextWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = { viewModel.activeQuiz = null },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    modifier = Modifier.height(32.dp),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Text("Quit", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Simple micro linear progress tracker
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(Color(0x0DFFFFFF))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth((viewModel.currentQuestionIndex + 1).toFloat() / totalQ.toFloat())
                        .clip(CircleShape)
                        .background(ElectricCyan)
                )
            }

            // Question Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0x0DFFFFFF))
                    .border(1.dp, Color(0x13FFFFFF), RoundedCornerShape(24.dp))
                    .padding(20.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(
                        text = question.questionText,
                        color = TextWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        lineHeight = 22.sp
                    )

                    // Display options if multiple choice or true/false, otherwise input text
                    val options = question.options
                    if (!options.isNullOrEmpty()) {
                        options.forEach { opt ->
                            val isSelected = viewModel.selectedAnswer == opt
                            val isSubmitted = viewModel.isAnswerSubmitted

                            val cardBgColor = when {
                                isSubmitted && opt == question.correctAnswer -> Color(0x264ADE80) // Green
                                isSubmitted && isSelected && opt != question.correctAnswer -> Color(0x26EF4444) // Red
                                isSelected -> Color(0x1A00F2FE) // Selected
                                else -> Color(0x0AFFFFFF)
                            }

                            val cardBorderColor = when {
                                isSubmitted && opt == question.correctAnswer -> Color(0xFF4ADE80)
                                isSubmitted && isSelected && opt != question.correctAnswer -> Color(0xFFEF4444)
                                isSelected -> ElectricCyan
                                else -> Color(0x0FFFFFFF)
                            }

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(cardBgColor)
                                    .border(1.dp, cardBorderColor, RoundedCornerShape(14.dp))
                                    .clickable(enabled = !isSubmitted) {
                                        viewModel.selectedAnswer = opt
                                    }
                                    .padding(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = opt,
                                        color = if (isSelected && !isSubmitted) ElectricCyan else TextWhite,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.weight(1f)
                                    )

                                    if (isSubmitted && opt == question.correctAnswer) {
                                        Icon(Icons.Default.Check, contentDescription = "Correct", tint = Color(0xFF4ADE80), modifier = Modifier.size(16.dp))
                                    } else if (isSubmitted && isSelected && opt != question.correctAnswer) {
                                        Icon(Icons.Default.Close, contentDescription = "Incorrect", tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    } else {
                        // Simple custom manual evaluation for Fill Blank or text
                        var textAnswerInput by remember { mutableStateOf("") }
                        OutlinedTextField(
                            value = textAnswerInput,
                            onValueChange = {
                                textAnswerInput = it
                                viewModel.selectedAnswer = it
                            },
                            placeholder = { Text("Type your answer here...", color = TextMuted, fontSize = 13.sp) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite,
                                focusedBorderColor = ElectricCyan,
                                unfocusedBorderColor = Color(0x1FFFFFFF)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            enabled = !viewModel.isAnswerSubmitted
                        )

                        if (viewModel.isAnswerSubmitted) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0x12FFFFFF))
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = "Correct answer: ${question.correctAnswer}",
                                    color = ElectricCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    // Bottom controls & answers explanation block
                    if (viewModel.isAnswerSubmitted) {
                        // Explanation panel
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x1A4FACFE))
                                .border(1.dp, Color(0x264FACFE), RoundedCornerShape(14.dp))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "AI Explanation:",
                                    color = BrightBlue,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = question.explanation,
                                    color = TextWhite,
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }

                        Button(
                            onClick = { viewModel.nextQuestion() },
                            colors = ButtonDefaults.buttonColors(containerColor = VividPurple),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().testTag("next_question_button")
                        ) {
                            Text(
                                text = if (viewModel.currentQuestionIndex + 1 == totalQ) "Complete Quiz" else "Next Question",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Button(
                            onClick = { viewModel.submitAnswer() },
                            enabled = viewModel.selectedAnswer != null,
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().testTag("submit_answer_button")
                        ) {
                            Text("Submit Answer", color = Color.Black, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }
    }
}

// --- TAB 4: SETTINGS SYSTEM ---
@Composable
fun SettingsTab(viewModel: StudyViewModel) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Tab Header
        Column {
            Text(
                text = "STUDY HUB TELEMETRY CONFIGURATION",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = BrightBlue,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            )
            Text(
                text = "Settings",
                style = MaterialTheme.typography.headlineMedium.copy(
                    color = TextWhite,
                    fontWeight = FontWeight.Black,
                    letterSpacing = (-0.5).sp
                )
            )
        }

        // Profile Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0x0DFFFFFF))
                .border(1.dp, Color(0x13FFFFFF), RoundedCornerShape(24.dp))
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(colors = listOf(ElectricCyan, VividPurple))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("S", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Black)
                }

                Column {
                    Text(
                        text = "Sarvagya Saxena",
                        color = TextWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "sarvagyasaxena2@gmail.com",
                        color = TextGray,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .background(Color(0x2600F2FE), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "PREMIUM MEMBER",
                            color = ElectricCyan,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Action Blocks (Database operations, mock data generation)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0x0DFFFFFF))
                .border(1.dp, Color(0x13FFFFFF), RoundedCornerShape(24.dp))
                .padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    text = "Developer Administration",
                    color = TextWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                // Inject mock statistics button
                Button(
                    onClick = {
                        viewModel.injectSampleData()
                        Toast.makeText(context, "Premium study telemetry mock data injected!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x1A4FACFE)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, BrightBlue, RoundedCornerShape(12.dp))
                        .testTag("inject_sample_data_button")
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CloudDownload, contentDescription = null, tint = BrightBlue, modifier = Modifier.size(16.dp))
                        Text("Inject Premium Sample Data", color = BrightBlue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

                // Reset App DB
                Button(
                    onClick = {
                        viewModel.resetAllData()
                        Toast.makeText(context, "Local SQLite Database cleared!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x1AEF4444)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFEF4444), RoundedCornerShape(12.dp))
                        .testTag("reset_all_data_button")
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                        Text("Reset Application Database", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        // Framework Info
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0x06FFFFFF))
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "ENGINE SPECS",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Sarvagya Hub Platform build v1.2.0-LTS",
                    color = TextGray,
                    fontSize = 11.sp
                )
                Text(
                    text = "Local persistence: SQLite/Room persistent architecture",
                    color = TextGray,
                    fontSize = 11.sp
                )
                Text(
                    text = "AI Orchestration: Gemini-3.5-Flash REST pipeline",
                    color = TextGray,
                    fontSize = 11.sp
                )
            }
        }
    }
}

// --- SHARED COMPONENT: GLASS BOTTOM NAVIGATION BAR ---
@Composable
fun GlassBottomNavigation(
    activeTab: ActiveTab,
    onTabSelected: (ActiveTab) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkBackground)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 24.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0x14FFFFFF))
                .border(1.dp, Color(0x13FFFFFF), RoundedCornerShape(20.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val items = listOf(
                NavigationItem(ActiveTab.HOME, "Home", Icons.Default.Home, Icons.Outlined.Home),
                NavigationItem(ActiveTab.LIBRARY, "Library", Icons.Default.Book, Icons.Outlined.Book),
                NavigationItem(ActiveTab.QUIZ, "Quiz", Icons.Default.Quiz, Icons.Outlined.Quiz),
                NavigationItem(ActiveTab.SETTINGS, "Settings", Icons.Default.Settings, Icons.Outlined.Settings)
            )

            items.forEach { item ->
                val isSelected = activeTab == item.tab

                // Animated active pill overlay
                val widthFrac by animateFloatAsState(
                    targetValue = if (isSelected) 1f else 0.8f,
                    animationSpec = spring(stiffness = Spring.StiffnessMedium),
                    label = "tab_width"
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) Color(0x264FACFE) else Color.Transparent)
                        .clickable {
                            onTabSelected(item.tab)
                        }
                        .testTag(item.tab.name.lowercase() + "_tab_button")
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                            contentDescription = item.label,
                            tint = if (isSelected) BrightBlue else TextGray.copy(alpha = 0.6f),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = item.label,
                            color = if (isSelected) BrightBlue else TextGray.copy(alpha = 0.6f),
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

data class NavigationItem(
    val tab: ActiveTab,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)
