package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Polish Theme Colors
val DarkBackground = Color(0xFF030014)
val SurfaceDark = Color(0xFF0B0820)
val GlassBackground = Color(0x730F0C1E)
val GlassBorder = Color(0x1AFFFFFF)

val ElectricCyan = Color(0xFF00F2FE)
val VividPurple = Color(0xFF7F00FF)
val BrightBlue = Color(0xFF4FACFE)
val SoftOrange = Color(0xFFFB923C)

val TextWhite = Color(0xFFF1F5F9)
val TextGray = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Material 3 Fallbacks
val PrimaryDark = Color(0xFF7F00FF)
val SecondaryDark = Color(0xFF00F2FE)
val TertiaryDark = Color(0xFF4FACFE)
